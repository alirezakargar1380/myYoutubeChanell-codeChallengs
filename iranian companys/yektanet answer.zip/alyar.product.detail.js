(function () {
  function extractIntFromText(elem) {
    if (!elem) {
      return;
    }
    elem = elem
      .toString()
      .replace(/۰/g, '0')
      .replace(/۱/g, '1')
      .replace(/۲/g, '2')
      .replace(/۳/g, '3')
      .replace(/۴/g, '4')
      .replace(/۵/g, '5')
      .replace(/۶/g, '6')
      .replace(/۷/g, '7')
      .replace(/۸/g, '8')
      .replace(/۹/g, '9')
      .replace(/\D/g, '');
    elem = parseInt(elem, 10);
    return elem;
  }

  function extractProductData() {
    var productInfo = {};

    var json = null;
    try {
      var ldJsons = document.querySelectorAll(
        'script[type="application/ld+json"]'
      );
      ldJsons.forEach(function (item) {
        item = JSON.parse(item.innerText);
        item = item && item['@graph'];
        item = item && item[0];
        if (item && item['@type'] === 'Product') {
          json = item;
        }
      });
    } catch (error) {
      console.error(error);
    }

    //sku
    var sku = json && json.sku;
    if (!sku) {
      return false;
    }
    productInfo.sku = sku;

    //title
    var title = json && json.name;
    if (title) {
      productInfo.title = title;
    }

    //image
    var image = document.querySelector('meta[property="og:image"]');
    image = image && image.content;
    if (image) {
      productInfo.image = image;
    }

    var offers = json && json.offers;
    offers = offers && offers[0];

    //price
    var price = offers && offers.price;
    price = price && extractIntFromText(price);
    if (price) {
      productInfo.price = price;
    }

    //discount
    var oldPrice = document.querySelector(
      'span.matrix_wolfold-price span.woocommerce-Price-amount'
    );
    oldPrice = oldPrice && oldPrice.innerText;
    oldPrice = oldPrice && extractIntFromText(oldPrice);
    var discount = 0;
    if (oldPrice && price) {
      discount = (100 * (oldPrice - price)) / oldPrice;
    }
    productInfo.discount = Math.round(discount);

    //isAvailable
    var isAvailable = offers && offers.availability;
    if (isAvailable) {
      productInfo.isAvailable = isAvailable === 'http://schema.org/InStock';
    }

    //category
    var category = document.querySelectorAll(
      'nav.woocommerce-breadcrumb span a'
    );
    productInfo.category = [];
    for (var i = 1; i < category.length; i++) {
      productInfo.category.push(category[i].innerText);
    }

    return productInfo;
  }

  function sendData() {
    try {
      var productInfo = extractProductData();

      if (productInfo && productInfo.sku && productInfo.title) {
        console.log(productInfo);
        // eslint-disable-next-line no-undef
        yektanet.product('detail', productInfo);
        return true;
      } else {
        return false;
      }
    } catch (e) {
      console.error(e);
      return false;
    }
  }

  if (sendData()) {
    return;
  }

  var retry = 0;
  var intervalId = setInterval(function () {
    if (retry++ > 5 || sendData()) {
      clearInterval(intervalId);
    }
  }, 1000);
})();
