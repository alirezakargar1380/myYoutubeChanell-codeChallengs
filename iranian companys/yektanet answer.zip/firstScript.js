(function () {
    function extractProductData() {
        var productInfo = {};
        var json = null;
        try {
            var ldJsons = document.querySelectorAll(
                'script[type="application/ld+json"]'
            );
            ldJsons.forEach(function (item) {
                item = JSON.parse(item.innerText);
                // console.log(item['@graph'][0]);
                if (item['@graph'])
                {
                    item = item['@graph'][0];
                }
                // console.log(item['@graph'][0]);
                // item['@type'] === "Organization"
                if (item['@type'] === "Product") {
                    // console.log(item);
                    json = item;
                }
            });
        } catch (error) {
            console.error(error);
        }

        // sku
        try {
            var sku = json && json.sku;
            if (!sku || sku === "undefined" ) {
                sku = json.productID;
            }
            if (!sku)
            {
                sku = "1";
            }
        } catch (e) {
            if (e) {
                sku = "1"
            }
        }
        productInfo.sku = sku;
        console.log(productInfo.sku);


        // title
        var title = json && json.name;
        if (title) {
            productInfo.title = title;
        }
        if (!title)
        {
            productInfo.title = document.querySelector('meta[property="og:title').content;
        }
        console.log(productInfo.title);


        // image
        var imag = document.querySelector('meta[property="og:image"]');
        imag = imag && imag.content;
        if (imag){
            productInfo.image = imag
        } else {
            var image = json && json.image['url'];
            if ( !image || image === "undefined" ) {
                image = json.image;
                productInfo.image = image;
            }
        }
        console.log(productInfo.image);

        // price
        var amount = document.querySelector('meta[property="product:price:amount"]');
        try {
            if (json.offers) {
                var price = json.offers;
                if (price[0])
                {
                    productInfo.price = price[0].price;
                } else {
                    productInfo.price = price.price;
                }
            }
        } catch (e) {
            if (e) {
                productInfo.price = amount.content;
            }
        }
        console.log(productInfo.price);

        // discount
        var oldPrice = document.querySelector("span.onsale");
        if (!oldPrice)
        {
            oldPrice = "0%";
            productInfo.discount = oldPrice;
        } else {
            oldPrice = oldPrice && oldPrice.innerHTML;
            productInfo.discount = oldPrice;
        }
        console.log(productInfo.discount);

        // available
        var available = document.querySelector("p.stock");
        var getDiv = document.querySelector(
            "div.tt-label-out-stock"
        );
        available = available && available.innerHTML;
        if (!available) {
            available = getDiv && getDiv.innerHTML;
            if (available === "اتمام موجودي"){
                var status = false;
            }
            if (!available) {
                status = true;
            }
        } else {
            if (available === "موجود در انبار") {
                status = true;
            } else {
                status = false;
            }
        }
        productInfo.isAvailable = status;
        console.log(productInfo.isAvailable);

        //expiration
        productInfo.expiration = 0;

        //category
        var category = document.querySelectorAll(
            'span.posted_in a'
        );
        if (category.length === 0)
        {
            category = document.querySelectorAll(
                'div.km-product-category a'
            );
        }

        productInfo.category = [];
        for (var i = 0; i < category.length; i++) {
            productInfo.category.push(category[i].innerText);
        }
        console.log(productInfo.category);

        // brand
        var brand = document.querySelectorAll(
            'td.woocommerce-product-attributes-item__value p'
        );
        try {
            if (brand.length === 0)
            {
                productInfo.brand = json.brand.name
            } else {
                productInfo.brand = brand[0].innerText;
            }
            if (productInfo.brand === "undefined")
            {
                productInfo.brand = "نا مشخص";
            }
        } catch (e) {
            if (e) {
                productInfo.brand = "نا مشخص";
            }
        }
        console.log(productInfo.brand);

        try {
            if (json.aggregateRating && json.aggregateRating !== "undefined") {
                console.log(172);
                var averageVote = json.aggregateRating.ratingValue;
                if (!averageVote)
                {
                    averageVote = 0;
                }
                productInfo.averageVote = averageVote;
            } else {
                productInfo.averageVote = 0;
            }

        } catch (e) {
            if (e)
            {
                productInfo.averageVote = 0;
            }
        }
        console.log(productInfo.averageVote);

        try {
            if (json.aggregateRating && json.aggregateRating !== "undefined") {
                var totalVotes = json.aggregateRating.reviewCount;
                if (!averageVote || totalVotes === "")
                {
                    totalVotes = 0;
                }
                productInfo.totalVotes = totalVotes;
            } else {
                productInfo.totalVotes = 0;
            }
        } catch (e) {
            if (e)
            {
                productInfo.totalVotes = 0;
            }
        }
        console.log(productInfo.totalVotes);
        console.log("__________________________________");

        return productInfo;
    }

    function sendData() {
        try {
            var productInfo = extractProductData();

            if (productInfo && productInfo.sku && productInfo.title) {
                console.log("this is your json file: ");
                console.log(productInfo);
                // eslint-disable-next-line no-undef
                return true;
            } else {
                return false;
            }

        } catch (e) {
            console.error(e);
            return false;
        }
    }


    if (sendData()) {
        return;
    }

    var retry = 0;
    var intervalId = setInterval(function () {
        if (retry++ > 2 || sendData()) {
            clearInterval(intervalId);
        }
    }, 1000);

})();

var price = querySelectorAll('span.tp-co-gr');
console.log(price.innerHTML);